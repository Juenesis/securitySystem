<?php
include('funciones.php');
$usuario=$_GET["usuario"];
$password=md5($_GET["password"]);

if($resultset=getSQLResultSet("Select tblusuarios.usuario,tblusuarios.password From tblusuarios Where tblusuarios.usuario='$usuario' and tblusuarios.password='$password'")){
	while ($row = $resultset->fetch_array(MYSQLI_NUM)){
		echo json_encode($row);
	}
}

?>


