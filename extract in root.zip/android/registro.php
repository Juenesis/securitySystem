<?php include ('funciones.php');
$activa=$_GET['activa'];

ejecutarSQLCommand("UPDATE tblactiva set activada = '".$activa."'");
echo "Actualizado";
 ?>