<!DOCTYPE html>
<html>
<head>
    <title>Registro de usuario</title>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.css"> 
    <link rel="stylesheet" type="text/css" href="../css/estilouno.css">
</head>
<body>
    <div class="container">
        
        <div class="row">
            <div class="col-md-12">
            <center><label><h2>Registro:</h2></label></center>
            <div class="form-group">
                <form class="form" action="accion.php" method="post">
                    <label class="form-control">
                    Nombre/s:*
                    <input type="text" name="nombre" class="form-control" placeholder="Nombre/s" required="true">
                    Apellidos:
                    <input type="text" name="nombre" class="form-control" placeholder="Apellidos" required="false">
                    Nombre de Usuario:*
                    <input type="text" name="nombre" class="form-control" placeholder="Usuario" required="true">
                    Correo Electrónico:*
                    <input type="email" name="nombre" class="form-control" placeholder="Usuario" required="true">
                    Contraseña:*
                    <input type="password" name="nombre" class="form-control" placeholder="Contraseña" required="true">
                    Confirmar Contraseña:*
                    <input type="password" name="nombre" class="form-control" placeholder="Confirmar Contraseña" required="true">
                    <center><button type="submit" class="btn btn-primary">Enviar</button></center>
                    </label>
                </form>
            </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
           <center> <a href="../pagina-uno.php"><button class="btn btn-primary">Volver a Inicio</button></a></center>
           </div>
        </div>

    </div>
</body>
</html>