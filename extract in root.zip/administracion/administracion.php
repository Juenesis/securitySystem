<!DOCTYPE html>
<html>
<head>
	<title>Inicio de sesión</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">	
	<link rel="stylesheet" type="text/css" href="../css/estilouno.css">
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-4"></div>
			<div class="col-md-4">
				<div class="form-group">
				<form class="form">
					<label class="form-control">Nombre de Usuario:
					<input class="form-control" type="text" name="usuario" placeholder="Usuario">
			         Contraseña:

					<input class="form-control" type="password" name="usuario" placeholder="Contraseña">
					 <hr>
					<center><button class="btn btn-default" type="submit">Entrar</button>
					</label>
					</center>
				</form>
				<center>
				<label class="form-control"><a href="registro.php">¿No tienes cuenta? Registrate aquí</a></label>
				</center>

				</div>
			</div>
		</div>

	</div>

</body>	 
</html>