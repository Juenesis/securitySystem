$(document).ready(function(){

	var btnId = document.getElementById('Enviar');
	btnId.addEventListener('click',function(e){
		e.preventDefault();
		var nom = document.getElementById("nombre");
		var apellido = document.getElementById("apellido");
		var user = document.getElementById("usuario");
		var correo = document.getElementById("email");
		var contra1 = document.getElementById("contra1");
		var contra2 = document.getElementById("contra2");
		var foto = document.getElementById("foto");

		if (nom.value != '' && apellido.value != '' && user.value != '' && correo.value != '' && contra1.value != '' && contra2.value != '') {
			console.log("cualquiercosa");
			var formulario = document.getElementById("formulario");
			var data = new FormData(formulario);

			/*
			data.append('nom',nom.value);
			data.append('apellido',apellido.value);
			data.append('user',user.value);
			data.append('correo',correo.value);
			data.append('contra2',contra2.value);
			data.append('contra1',contra1.value);
			data.append('foto',foto.files[0]);
			*/
			$.ajax({

				type: 'POST',
				url:'../system/enviar-agusuario.php',
				contentType:false,
				processData:false,
				data: data,
				cache: false,
				success: function (a){
					console.log(a);
				},error: function (d){
					console.log(d);
				}

			});

		}else{
			alert("Llena todos los campos");
		}

	});



});
