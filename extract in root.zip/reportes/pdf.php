<?php
  session_start();
  require("../system/conexion.php");
  $table="";
$sql="SELECT * FROM tbllogs order by id desc";
                    $result=mysqli_query($conn, $sql);

                    while ($row=mysqli_fetch_array($result)) {
                      $fecha=strtotime($row["log2"]);
                      $fecha2=date('d/m/Y H:i:s',$fecha);
                        $table=$table."<tr>";
                          $table=$table."<td data-tittle='numero'>".$row["id"];
                          $table=$table."</td>";
                          $table=$table."<td data-tittle='fecha'>".$fecha2."</td>";
                        $table=$table."</tr>";
                    }
 ?>
<?php
  require_once('dompdf/autoload.inc.php');
  use Dompdf\Dompdf;
  $css = file_get_contents('pdf.css');
  $css2 = file_get_contents('table.css');
  // Introducimos HTML de prueba
  $html ="<style>".$css."</style>".$html2="<div class='main-header'>
        <div class='header'>
          <div class='logo'>
            <img src='fondo.png'>
          </div>
          <div class='title'>
            <h1>Reporte de Registros</h1>
          </div>
        </div>
    </div>
    <br>
    <div class='data-user'>
    </div>
    <br>
    <div class='table keywords'>
      <table id='example' class='mdl-data-table' style='width:100%'>
    <thead>
      <tr>
        <th >Numero de Registro</th>
        <th colspan='2'>Registro</th>
      </tr>
    </thead>
    <tbody>
    ".$table."
    </tbody>
    <tfoot>
    </tfoot>
  </table>
    </div>";

  // Instanciamos un objeto de la clase DOMPDF.
  $pdf = new DOMPDF();

  // Definimos el tamaño y orientación del papel que queremos.
  $pdf->set_paper("A4", "portrait");

  //Cargamos el contenido HTML.
  $pdf->load_html(utf8_decode($html));

  // Renderizamos el documento PDF.
  $pdf->render();

  // Enviamos el fichero PDF al navegador.
  $pdf->stream('report.pdf');
echo $html;

 ?>
