<?php
$servername = "redeskevin.com";
$username = "robertgg47";
$password = "nerv";
$dbname ="alarma";
// Crear conexion
$conn = mysqli_connect($servername, $username, $password,$dbname);
// revisar conexion
if (mysqli_connect_errno()) {
 echo "failed to connect to MySQL: ".mysqli_connect_error();
} 
?>