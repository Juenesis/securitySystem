<?php
/*
$to       = 'juan.david.1806@gmail.com';
$subject  = 'Testing sendmail.exe';
$message  = 'Hi, you just received an email using sendmail!';
$headers  = 'From: esteesuncorreo123@gmail.com' . "\r\n" .
            'MIME-Version: 1.0' . "\r\n" .
            'Content-type: text/html; charset=utf-8';
if(mail($to, $subject, $message, $headers))
    echo "Email sent";
else
    echo "Email sending failed";
*/




ini_set("SMTP","smtp.gmail.com" );
ini_set("ssl:smtp_port","465");
ini_set('sendmail_from', 'esteesuncorreo123@gmail.com');          
$to = "juan.david.1806@gmail.com";
$subject = "Test mail";
$message = "Hello! This is a simple email message.";
$from = "esteesuncorreo123@gmail.com";
$headers = "From:" . $from;
$retval = mail($to,$subject,$message,$headers);
   if( $retval == true )  
   {
      echo "Message sent successfully...";
   }
   else
   {
      echo "Message could not be sent...";
   }

$mail = "Prueba de mensaje";
//Titulo
$titulo = "PRUEBA DE TITULO";
//cabecera
$headers = "MIME-Version: 1.0\r\n"; 
$headers .= "Content-type: text/html; charset=iso-8859-1\r\n"; 
//dirección del remitente 
$headers .= "From: Geeky Theory esteesuncorreo12@gmail.com\r\n";
//Enviamos el mensaje a tu_dirección_email 
$bool = mail("david.salcedo@alumnos.udg.mx",$titulo,$mail,$headers);
if($bool){
    echo "Mensaje enviado";
}else{
    echo "Mensaje no enviado";
}
?>