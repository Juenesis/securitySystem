<?php //echo $_GET['x']; 
require("conexion.php");
$x=$_GET['x'];
$msg="";
$sql="UPDATE tblactiva set activada=$x where id=1";
$result=mysqli_query($conn,$sql);
if ($result) {
	switch ($x) {
		case '0':
		$msg.="Alarma Desactivada completamente.";
			break;
		case '1':
		$msg.="Alarma Activada.";
			break;
		default:
			$msg.="Algo salió mal. Error: SNDSW";
			break;
	}
}
	
	echo "<h2 style='color:red;'>$msg</h2>";
?>