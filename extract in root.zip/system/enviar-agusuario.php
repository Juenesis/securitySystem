<?php 
		require("conexion.php");
		session_start();
		$nombre = $_POST['nombre'];
		$apellidos=$_POST['apellido'];
		$usuario = $_POST['usuario'];
		$contrasena=md5($_POST['pass']);
		$contrasena2=md5($_POST['pass2']);
		$correo = $_POST['correo'];
		$foto = $_FILES['foto']['name'];
		
		$target_path = "../personas/";
		$target_path = $target_path . basename( $_FILES['foto']['name']); 

		if ($_FILES['foto']['size']>2000000) {

		} else {
			if (!($_FILES['foto']['type'] =="image/jpeg" OR $_FILES['foto']['type'] =="image/png")){

			}else{
				if(move_uploaded_file($_FILES['foto']['tmp_name'], $target_path)) { 
					$message= "";            } else{
						echo "Ha ocurrido un error, trate de nuevo!";
					}
				}
			}
	    //Fin agregar imagen
			$imagen=$target_path;
			if ($contrasena == $contrasena2) {
				$sql = "INSERT INTO tblusuarios(usuario,password) values('$usuario','$contrasena')";
				$result = mysqli_query($conn,$sql);
				if ($result) {
					$sql = "SELECT id FROM tblusuarios Where usuario='$usuario' and password = '$contrasena'";
					$result = mysqli_query($conn,$sql);
					while ($row = mysqli_fetch_array($result)) {
						$idnew = $row['id'];
					}
					$sql = "INSERT INTO tbldatos(nombres,apellidos,imagen,tblusuarios_id) values('$nombre','$apellidos','$imagen','$idnew')";
					$result = mysqli_query($conn,$sql);
					if ($result) {
						$sql = "SELECT id from tblcorreos order by id DESC LIMIT 1";
					$result = mysqli_query($conn,$sql);
					while ($row = mysqli_fetch_array($result)) {
						$idnewcorreo = $row['id'];
					}
					$newcorreo = $idnewcorreo+1;

					echo "$newcorreo $correo $idnew";
						$sql = "INSERT INTO tblcorreos values('$newcorreo','$correo','$idnew')";
					$result = mysqli_query($conn,$sql);
					if ($result) {
						echo "Usuario agregado correctamente";
						$_SESSION['menUsu'] = "Usuario Agregado Correctamente";
						header("Location:agregar-usuarios.php");
					}else{
						echo "error al agregar correo";
					}
					}else{
						echo"Error al insertar Datos";
					}
				}else{
					echo "No se pudo insertar usuario";
				}
			}else{
				echo "Las contraseñas no coinciden";
			}



	
 ?>