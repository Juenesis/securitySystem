<?php 
require("conexion.php");
session_start();
$aleatorio=$_SESSION['aleatorio'];
$usuario=$_SESSION['usuario'];
$sql="SELECT id FROM tblusuarios WHERE usuario='$usuario'";
$result=mysqli_query($conn,$sql);
if ($result) {
	$row=mysqli_fetch_array($result);
	$id=$row['id'];
	$_SESSION['id'] = $id;
	$sql1="INSERT INTO tblcodigos(codigo,tblusuarios_id) VALUES ('".$aleatorio."','".$id."')";
	$resultado=mysqli_query($conn,$sql1);
	if ($resultado) {
	}
}
if (!isset($_POST['enviar'])) {
	?>
		<!DOCTYPE html>
		<html>
		<head>
			<meta charset="utf-8">
			<title>Recuperando contraseña.</title>
			<link rel="stylesheet" href="../css/style.css">

		</head>
		<body>
			<div class="container">
				<section id="content">
					<form action="nuevo-password.php" method="post">
						<h1>Recuperación <br>de contraseña</h1>
						<div>
							<h1>Se ha enviado un correo con el código de recuperación.</h1>
							<?php //echo $_SESSION['correo']; ?>
						</div>
						<div>
							<input type="text" placeholder="Código de recuperación:" name="codigo_recuperacion" required="true">
						</div>
						<div>
							<input type="submit" value="Continuar" name="enviar" />
						</div>
					</form>
				</section>
			</div>
		</body>
		</html>
		<script  src="js/index.js"></script>
		<?php
}else{
	$codigo_escrito=$_POST['codigo_recuperacion'];
		$sql="SELECT * FROM tblcodigos where tblusuarios_id='".$_SESSION['id']."' order by id desc limit 1 ";
		$result=mysqli_query($conn,$sql);
		$row=mysqli_fetch_array($result);
		$código_DB=$row['codigo'];
		
		if ($código_DB == $codigo_escrito) {
			header("location:../cambiar-email.php");
		}else{
			echo "<h1>Código equivocado</h1>";
		}
}
?>