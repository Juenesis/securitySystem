<?php  
		session_start();
		if (isset($_SESSION['mensaje'])) {
			echo "1";
			$msg=$_SESSION['mensaje'];
			
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Comentarios</title>
	<link rel="stylesheet" href="../css/bootstrap.css">
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<h1><?php echo $msg; session_destroy(); ?></h1>
				<form method="get" id="comentarios" class="form-group" action="enviar-comentarios.php">
					<label class="form-control">
						<label class="form-control"><h1>Comentarios</h1></label>
					
					<hr>
					<label>Nombre:
						<input type="text" name="nombre" class="form-control" placeholder="Nombre/s">
					</label>
					<label>Apellido:
						<input type="text" name="apellido" class="form-control" placeholder="Apellidos">
					</label>
					<label>Correo:
						<input type="email" name="correo" class="form-control" placeholder="Correo">
					</label>
					<label>Comentario:
						<input type="text" name="comentario" class="form-control" placeholder="Escriba sus comentarios aquí.">
					</label>
					<hr>
					<label class="form-control">
						<input type="submit" class="btn btn-primary" name="enviar">
					</label>
				</form>
				</label>
			</div>
		</div>
	</div>
</body>
</html>
<?php
	}else{
		?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Comentarios</title>
	<link rel="stylesheet" href="../css/bootstrap.css">
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<form method="get" id="comentarios" class="form-group" action="enviar-comentarios.php">
					<label class="form-control">
						<label class="form-control"><h1>Comentarios</h1></label>
					
					<hr>
					<label>Nombre:
						<input type="text" name="nombre" class="form-control" placeholder="Nombre/s">
					</label>
					<label>Apellido:
						<input type="text" name="apellido" class="form-control" placeholder="Apellidos">
					</label>
					<label>Correo:
						<input type="email" name="correo" class="form-control" placeholder="Correo">
					</label>
					<label>Comentario:
						<input type="text" name="comentario" class="form-control" placeholder="Escriba sus comentarios aquí.">
					</label>
					<hr>
					<label class="form-control">
						<input type="submit" class="btn btn-primary" name="enviar">
					</label>
				</form>
				</label>
			</div>
		</div>
	</div>
</body>
</html>
		<?php
	}
?>