<?php session_start(); 
require("conexion.php");
if (!isset($_SESSION["usuario"])) {
	header("location: ../login-modular.php");
}else{

	?>
	<!DOCTYPE html>
	<html lang="es">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">

		<title>Página Principal</title>
		<link href="../css/bootstrap.css" rel="stylesheet">
		<link href="../css/sidebar.css" rel="stylesheet">
		<link rel="stylesheet" href="../css/galeria.css">
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Material+Icons">
		<link rel="shortcut icon" href="../icono/seguridad-icono1.png">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.css">
	</head>
	<body>
		<?php require ("sidebar.php") ?>
		<div id="page-content-wrapper">
			<?php require ("top-bar.php") ?>
			<div class="container-fluid">
				<?php 
				$sql= "SELECT * From tblimagenes";
				$result=mysqli_query($conn,$sql);

				if (mysqli_num_rows($result) > 0) {
					$i=0;
					while ($row = mysqli_fetch_array($result)) {
						$arregloimg[$i]=$row["ruta"];
						$arreglofecha[$i]=$row["fecha"];
						$i++;
					}
				}
				?>
				<div class="container gallery-container">

					<h1>Sistema de Seguridad Inteligente</h1>
					<center><div id="demo"></div></center>
					<p class="page-description text-center">Bienvenido al sistema.</p>
					<div class="row">
						<div class="col-md-12 col-xs-12 centered well">
							<h3>Últimos Registros.</h3>
							<div class="table-responsive" id="tablaimportante">
								<table id="myTable" class="table table-striped table-hover">
									<thead>
										<tr>
											<th>Número de registro</th>
											<th>Registro</th>
											
										</tr>
									</thead>
									<tbody>
										<?php 
										$sql="SELECT * FROM tbllogs order by id desc  LIMIT 25;";
										$result=mysqli_query($conn, $sql);

										while ($row=mysqli_fetch_array($result)) {
											$fecha=strtotime($row["log2"]);
											$fecha2=date('d/m/Y H:i:s',$fecha);
											echo ('<tr><td data-tittle="numero">'.$row["id"].'</td>
											<td data-tittle="fecha">'.$fecha2.'</td></tr>');
										}
										?>
									</tbody>
								</table>

							</div>
						</div>
						
					</div>
					<a href="../reportes/pdf.php" class="btn btn-alert">Reporte</a>	
				</div>
			</div>
		</div>
	</div>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.js"></script>
	<script src="../js/jquery.min.js"></script>
<script src="../js/bootstrap.bundle.min.js"></script>
	<script type="text/javascript" src="../js/server-petition.js"></script>
	<script type="text/javascript" src="../js/dataTable.js"></script>
	<script type="text/javascript">	
	$("#menu-toggle").click(function(e) {
				e.preventDefault();
				$("#wrapper").toggleClass("toggled");
			});	
		$(document).ready(function(){
			$('#myTable').dataTable({
				language: {
					"sProcessing":     "Procesando...",
					"sLengthMenu":     "Mostrar _MENU_ registros",
					"sZeroRecords":    "No se encontraron resultados",
					"sEmptyTable":     "Ningún dato disponible en esta tabla",
					"sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
					"sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
					"sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
					"sInfoPostFix":    "",
					"sSearch":         "Buscar:",
					"sUrl":            "",
					"sInfoThousands":  ",",
					"sLoadingRecords": "Cargando...",
					"oPaginate": {
						"sFirst":    "Primero",
						"sLast":     "Último",
						"sNext":     "Siguiente",
						"sPrevious": "Anterior"
					},
					"oAria": {
						"sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
						"sSortDescending": ": Activar para ordenar la columna de manera descendente"
					}
				}
			});
		});
		
	</script>
</body>
</html>
<?php } ?>