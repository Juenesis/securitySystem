<?php 
require_once('PHPMailer/class.phpmailer.php');
$mail = new PHPMailer();
$mail->IsSMTP();
$mail->SMTPDebug = 2;
$mail->SMTPAuth = true;
$mail->SMTPSecure = "ssl";
$mail->Host = "smtp.gmail.com";
$mail->Port = 465;
$mail->Username = "sistemaseguridadrpi@gmail.com";
$mail->Password = "lostreschatos";
$mail->SetFrom('sistemaseguridadrpi@gmail.com', 'Nombre completo');
$mail->AddReplyTo("sistemaseguridadrpi@gmail.com","Nombre completo");
$mail->Subject = "Envío de email usando SMTP de Gmail";
$mail->MsgHTML("Hola que tal, esto es el cuerpo del mensaje!");
//indico destinatario
$address = "juan.david.1806@gmail.com";
$mail->AddAddress($address, "Nombre completo");
if(!$mail->Send()) {
echo "Error al enviar: " . $mail­>ErrorInfo;
} else {
echo "Mensaje enviado!";
}
 ?>