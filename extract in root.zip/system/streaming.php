<?php session_start(); 
require("conexion.php");
if (!isset($_SESSION["usuario"])) {
	header("location: ../login-modular.php");
}else{
	?>

	<!DOCTYPE html>
	<html lang="es">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">

		<title>Página Principal</title>
		<link href="../css/bootstrap.css" rel="stylesheet">
		<link href="../css/sidebar.css" rel="stylesheet">
		<link rel="stylesheet" href="../css/galeria.css">
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Material+Icons">
		<link rel="shortcut icon" href="../icono/seguridad-icono1.png">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.css">
	</head>
	<body>
		<?php require ("sidebar.php") ?>
		<div id="page-content-wrapper">
			<?php require ("top-bar.php") ?>
			<div class="container-fluid">
			<!-- All content here-->
			
			<div class="container gallery-container">

				<h1>Transmisión en vivo</h1>
				<section>
						<div>
							<center><img id="" src="http://172.16.2.82:5000/video_feed" class="img-thumbnail" width="50%" height="50%"></img></center>
						</div>
				</section>
			</div>
			</div>
		</div>
	</div>


	<script src="../js/jquery.min.js"></script>
	<script src="../js/bootstrap.bundle.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.js"></script>
	<script>
		baguetteBox.run('.tz-gallery');
	</script>
	<script type="text/javascript" src="../js/server-petition.js"></script>
	<script>
		$("#menu-toggle").click(function(e) {
			e.preventDefault();
			$("#wrapper").toggleClass("toggled");
		});
	</script>
</body>

</html>
	<?php } ?>