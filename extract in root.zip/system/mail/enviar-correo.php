<?php 
require_once('PHPMailer/class.phpmailer.php');
$mail = new PHPMailer();
$mail->IsSMTP();
$mail->SMTPDebug = 2;
$mail->SMTPAuth = true;
$mail->SMTPSecure = "ssl";
$mail->Host = "smtp.gmail.com";
$mail->Port = 465;
$mail->Username = "vallarpie.podologia@gmail.com";
$mail->Password = "vallarpie.po";
$mail->SetFrom('vallarpie.podologia@gmail.com', 'Nombre completo');
$mail->AddReplyTo("vallarpie.podologia@gmail.com","Nombre completo");
$mail->Subject = "Envío de email usando SMTP de Gmail";
$mail->MsgHTML("Hola que tal, esto es el cuerpo del mensaje!");
//indico destinatario
$address = "'".$_SESSION['session_username']."'";
$mail->AddAddress($address, "Nombre completo");
if(!$mail->Send()) {
echo "Error al enviar: " . $mail­>ErrorInfo;
} else {
echo "Mensaje enviado!";
}
 ?>