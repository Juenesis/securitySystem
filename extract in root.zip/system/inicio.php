<?php 
require("conexion.php");
$usuario=$_POST['user'];
$password=md5($_POST['pass']);


if (isset($_POST['enviar'])) {
	echo "flag 1";
	$sql="SELECT * from tblusuarios inner join tbldatos on tblusuarios.id=tblusuarios_id where usuario='$usuario' and password='$password'";
	$result=mysqli_query($conn,$sql);
	echo "flag2";
	if ($result) {
		$row=mysqli_fetch_array($result);
		session_start();
		$_SESSION["id"] = $row ['id'];
		$_SESSION['usuario']=$row['usuario'];
		$_SESSION['contrasena']=$row['contrasena'];
		$_SESSION['image']=$row['imagen'];

		echo $_SESSION['usuario'].$_SESSION['contrasena'];
		header("location:principal.php");
	}
	

	echo "flag 3";


}else{
	echo "flag 4";
	header("location:../login-modular.php");
}

?>
