<div id="wrapper" class="toggled">
			<div id="sidebar-wrapper">
				<ul class="sidebar-nav">
					<li><img class="custom-image" src="<?php echo $_SESSION['image']; ?>" alt="" /><h3 class="custom-h3">
						Bienvenido <?php echo $_SESSION['usuario']; ?>
					</h3>
				</li>
				<li class="sidebar-brand">
					<a href="#">
						<center>Página principal</center>
					</a>
				</li>
				<li>
					<a href="streaming.php"><button class="btn btn-link btn-block" >Video en Vivo</button></a>
				</li>
				
				<li>
					<a href="#"><button id="0" class="btn btn-link btn-block" onclick="loadDoc(this.id);desactivada();">Desactivar</button></a>
				</li>
				<li>
					<button id="1" class="btn btn-danger btn-block"  onclick="loadDoc(this.id);activada();">Activar</button>
				</li>
				<li>
					<center>					
					<?php 
						require("conexion.php");
						$sql = "SELECT * From tblactiva where id=1";
						$result = mysqli_query($conn,$sql);
						$row = mysqli_fetch_array($result);
					if ($row['activada'] == 1) {
						?>
						
						<p style="color: #fff">Estado: Activada.</p>

						<img src="../img/verde.png" width="100px;">
						<?php }else{ ?>
						<p style="color: #fff">Estado: Desactivada.</p>
						<img src="../img/rojo.png" width="100px">
						<?php } ?>
						</center>
				</li>
			</ul>
		</div>