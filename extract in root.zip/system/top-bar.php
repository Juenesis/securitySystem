<a href="#menu-toggle" id="menu-toggle" class="custom-button"><span class=""><img src="../glyphicons/flechitaregresar.png" alt="" style="margin-left: -20px;"></span></a>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark	">
	<a class="navbar-brand" href="principal.php">Página principal</a>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
	aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
	<div class="collapse navbar-collapse " id="navbarSupportedContent">
		<ul class="navbar-nav mr-auto">
			<li class="nav-item">
				<a href="streaming.php"><button class="btn btn-link">Video en vivo</button></a>
			</li>
			
			<li class="nav-item">
				<button id="0" class="btn btn-link" onclick="loadDoc(this.id);desactivada();">Desactivar</button> 
			</li>
			<li class="nav-item">
				<button id="1" class="btn btn-danger"  onclick="loadDoc(this.id); activada();">Activar</button> 
			</li>
		</ul>

		<ul class="navbar-nav ml-auto nav-flex-icons">
			<li class="nav-item avatar dropdown">
				<a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink-5" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="<?php echo $_SESSION['image']; ?>" class="img-fluid rounded-circle z-depth-0" width="30"></a>
				<div class="dropdown-menu dropdown-menu-right dropdown-purple" aria-labelledby="navbarDropdownMenuLink-5">
					<a class="dropdown-item whov" href="editar-cuenta.php"><i class="fa fa-plus"></i> Editar cuenta</a>
					<a class="dropdown-item whov" href="agregar-usuarios.php"><i class="fa fa-edit"></i> Agregar Usuarios</a>
					<a class="dropdown-item whov" href="logout.php"><i class="fa fa-edit"></i> Cerrar sesión</a>
				</div>
			</li>
		</ul>
	</div>
</nav>
<script>
	function activada(){
		alert("Alarma Activada");
	}

	function desactivada(){
		alert("Alarma Desactivada");
	}

</script>