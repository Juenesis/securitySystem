<?php session_start(); 
require("conexion.php");
if (!isset($_SESSION["usuario"])) {
	header("location: ../login-modular.php");
}else{
	if (!isset($_POST['Modificar'])) {
		?>
		<!DOCTYPE html>
		<html lang="es">
		<head>
			<meta charset="utf-8">
			<meta http-equiv="X-UA-Compatible" content="IE=edge">
			<meta name="viewport" content="width=device-width, initial-scale=1">

			<title>Página Principal</title>
			<link href="../css/bootstrap.css" rel="stylesheet">
			<link href="../css/sidebar.css" rel="stylesheet">
			<link rel="stylesheet" href="../css/galeria.css">
			<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Material+Icons">
			<link rel="shortcut icon" href="../icono/seguridad-icono1.png">
			<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.css">
		</head>
		<body>
			<?php require ("sidebar.php") ?>
			<div id="page-content-wrapper">
				<?php require ("top-bar.php") ?>
				<div class="container-fluid">
					<?php 
					//echo $_SESSION['usuario'];
					$sql= "SELECT * From tbldatos inner join tblusuarios on tblusuarios_id = tbldatos.id where usuario='".$_SESSION['usuario']."'";
					$result=mysqli_query($conn,$sql);
					if (mysqli_num_rows($result)>0) {
						while ($row = mysqli_fetch_array($result)) {
							$imagen = $row['imagen'];
							$nombres= $row['nombres'];
							$apellido=$row['apellidos'];
							$usuario = $row['usuario'];
							$contra= $row['password'];
							$_SESSION['id']=$row['tblusuarios_id'];
							$_SESSION['tempcontra'] = $contra;
						}
					}
					?>
					<div class="container gallery-container">

						<h1>Editar Perfil</h1>
						<center><div id="demo"></div></center>
						<?php echo "<center><img src='".$imagen."' width='200px;' class='img-thumbnail'></center>"; ?>
						<div class="row">

							<div class="col-md-12 col-xs-12 centered well">
								<form action="editar-cuenta.php" method="POST" enctype="multipart/form-data">
									<hr>
									<center>
										<label for="" class="form-group">Nombre/s:
											<input value=<?php echo "'".$nombres."'"; ?> type="text" name="nombre" placeholder="Nombre/s" class="form-control">
											<hr>
											<label for="">Apellido/s:</label>
											<input value=<?php echo "'".$apellido."'"; ?>	type="text" name="apellido" placeholder="Apellido/s" class="form-control">
											<hr>
											<label for="">Usuario:</label>
											<input value=<?php echo "'".$usuario."'"; ?> type="text" name="usuario" placeholder="Usuario" class="form-control" readonly>
											<hr>
											<label for="">Contraseña:</label>
											<input value=<?php echo "'".$contra."'"; ?> type="password" name="contrasena" placeholder="Contrasena" class="form-control" onfocus="pass();" id="contra1">
											<hr>
											<label for="">Confirmar Contraseña:</label>
											<input value=<?php echo "'".$contra."'"; ?> type="password" name="contrasena2" placeholder="Confirmar Contrasena" class="form-control" id="contra2">
											<hr>
											<label for="">Imagen:</label>
											<input type="file" name="foto" required>
										</label>
										<hr>
										<input type="submit" value="Actualizar Perfil" name="Modificar" class="btn btn-primary">
										<hr>
									</center>
								</form>
							</div>

						</div>
					</div>
				</div>
			</div>
		</div>
		<script>
			function pass(){
				//var pass = document.getElementById('contra1').value;
				//var pass2 = document.getElementById('contra2').value;
				$('#contra1').val('');
				$('#contra2').val('');
			}
		</script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.js"></script>
		<script src="../js/jquery.min.js"></script>
		<script src="../js/bootstrap.bundle.min.js"></script>
		<script type="text/javascript" src="../js/server-petition.js"></script>
		<script type="text/javascript">	
			$("#menu-toggle").click(function(e) {
				e.preventDefault();
				$("#wrapper").toggleClass("toggled");
			});	


		</script>
	</body>
	</html>
	<?php } else{

		$nombre = $_POST['nombre'];
		$apellidos=$_POST['apellido'];
		$usuario = $_POST['usuario'];
		if ($_POST["contrasena"] == "" OR $_POST["contrasena2"]=="") {
			$contrasena = $_SESSION['tempcontra'];
			$contrasena2 = $_SESSION['tempcontra'];
		}else{
		$contrasena=md5($_POST['contrasena']);
		$contrasena2=md5($_POST['contrasena2']);
		}
		//Para agregar la imagen
		$target_path = "../personas/";
		$target_path = $target_path . basename( $_FILES['foto']['name']); 

		if ($_FILES['foto']['size']>2000000) {

		} else {
			if (!($_FILES['foto']['type'] =="image/jpeg" OR $_FILES['foto']['type'] =="image/png")){

			}else{
				if(move_uploaded_file($_FILES['foto']['tmp_name'], $target_path)) { 
					$message= "";            } else{
						echo "Ha ocurrido un error, trate de nuevo!";
					}
				}
			}
	    //Fin agregar imagen
			$imagen=$target_path;
			?>
			<!DOCTYPE html>
			<html lang="es">
			<head>
				<meta charset="utf-8">
				<meta http-equiv="X-UA-Compatible" content="IE=edge">
				<meta name="viewport" content="width=device-width, initial-scale=1">

				<title>Página Principal</title>
				<link href="../css/bootstrap.css" rel="stylesheet">
				<link href="../css/sidebar.css" rel="stylesheet">
				<link rel="stylesheet" href="../css/galeria.css">
				<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Material+Icons">
				<link rel="shortcut icon" href="../icono/seguridad-icono1.png">
				<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.css">
			</head>
			<body>
				<?php require ("sidebar.php") ?>
				<div id="page-content-wrapper">
					<?php require ("top-bar.php") ?>
					<div class="container-fluid">
						<?php 
						if ($contrasena2 == $contrasena) {
							$sql = "UPDATE tbldatos set nombres ='".$nombre."', apellidos= '".$apellidos."', imagen = '".$imagen."' where tblusuarios_id='".$_SESSION['id']."'";
							$result=mysqli_query($conn,$sql);
							if ($result) {
								$sql = "UPDATE tblusuarios set tblusuarios.password ='$contrasena'";
								$result=mysqli_query($conn,$sql);
								if ($result) {
									$msg= "<center><h1>Perfil Actualizado Correctamente</h1></center>";
								}else{
									$msg= "<center><h1>Error al actualizar contraseña</h1></center>";
								}
								
							}
						}else{
							$msg='<center><h1>Las contraseñas no coinciden</h1></center>';
						}

						?>
						<div class="container gallery-container">

							<h1>Editar Perfil</h1>
							<center><div id="demo"></div></center>
							<?php echo "<center><img src='".$imagen."' width='200px;' class='img-thumbnail'></center>"; ?>
							<?php echo $msg; ?>
							<div class="row">

								<div class="col-md-12 col-xs-12 centered well">
									<form action="editar-cuenta.php" method="POST" enctype="multipart/form-data">
										<hr>
										<center>
											<label for="" class="form-group">Nombre/s:
												<input value=<?php echo "'".$nombre."'"; ?> type="text" name="nombre" placeholder="Nombre/s" class="form-control">
												<hr>
												<label for="">Apellido/s:</label>
												<input value=<?php echo "'".$apellidos."'"; ?>	type="text" name="apellido" placeholder="Apellido/s" class="form-control">
												<hr>
												<label for="">Usuario:</label>
												<input value=<?php echo "'".$usuario."'"; ?> type="text" name="usuario" placeholder="Usuario" class="form-control" readonly>
												<hr>
												<label for="">Contraseña:</label>
												<input value=<?php echo "'".$contrasena."'"; ?> type="password" name="contrasena" placeholder="Contrasena" class="form-control" id="contra1" onfocus="pass();">
												<hr>
												<label for="">Confirmar Contraseña:</label>
												<input value=<?php echo "'".$contrasena."'"; ?> type="password" name="contrasena2" placeholder="Confirmar Contrasena" class="form-control" id="contra2">
												<hr>
												<label for="">Imagen:</label>
												<input type="file" name="foto" required>
											</label>
											<hr>
											<input type="submit" value="Actualizar Perfil" name="Modificar" class="btn btn-primary">
											<hr>
										</center>
									</form>
								</div>

							</div>
						</div>
					</div>
				</div>
			</div>

			<script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.js"></script>
			<script src="../js/jquery.min.js"></script>
			<script src="../js/bootstrap.bundle.min.js"></script>
			<script type="text/javascript" src="../js/server-petition.js"></script>
			<script type="text/javascript">	
				function pass(){
				//var pass = document.getElementById('contra1').value;
				//var pass2 = document.getElementById('contra2').value;
				$('#contra1').val('');
				$('#contra2').val('');
			}
				$("#menu-toggle").click(function(e) {
					e.preventDefault();
					$("#wrapper").toggleClass("toggled");
				});	


			</script>
		</body>
		</html>
		<?php 
	}
}?>