<?php session_start(); 
require("conexion.php");
if (!isset($_SESSION["usuario"])) {
	header("location: ../login-modular.php");
}else{
	if (isset($_SESSION['menUsu'])) {
		# code...

		?>
		<!DOCTYPE html>
		<html lang="es">
		<head>
			<meta charset="utf-8">
			<meta http-equiv="X-UA-Compatible" content="IE=edge">
			<meta name="viewport" content="width=device-width, initial-scale=1">

			<title>Página Principal</title>
			<link href="../css/bootstrap.css" rel="stylesheet">
			<link href="../css/sidebar.css" rel="stylesheet">
			<link rel="stylesheet" href="../css/galeria.css">
			<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Material+Icons">
			<link rel="shortcut icon" href="../icono/seguridad-icono1.png">
			<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.css">
		</head>
		<body>

			<?php require ("sidebar.php") ?>
			<div id="page-content-wrapper">
				<?php require ("top-bar.php") ?>
				<div class="container-fluid">
					<?php 

					?>
					<div class="container gallery-container">
						<?php echo "<center><h2 style='color: blue'>".$_SESSION['menUsu']."</h2></center>"; ?>	

						<h1 >Agregar un usuario nuevo.</h1>
						<center></center>
						<div class="row">
							<div class="col-md-12 col-xs-12 centered well">
								<form id="formulario" method="post" class="formcontrol" action="enviar-agusuario.php" enctype="multipart/form-data">
									<div class="form-group"><h3>Nombre/s:</h3>
										<input type="text" placeholder="Nombre/s" name="nombre" class="form-control" id="nombre">
									</div>
									<div class="form-group"><h3>Apellido/s:</h3>
										<input type="text" placeholder="Apellido/s" name="apellido" class="form-control" id="apellido">
									</div>
									<div class="form-group"><h3>Usuario:</h3>
										<input type="text" placeholder="Nombre de usuario" name="usuario" class="form-control" id="usuario">
									</div>
									<div class="form-group"><h3>Correo:</h3>
										<input type="text" placeholder="Correo Electrónico" name="correo" class="form-control" id="email">
									</div>
									<div class="form-group"><h3>Contraseña:</h3>
										<input type="password" placeholder="Contraseña" name="pass" class="form-control" id="contra1">
									</div>
									<div class="form-group"><h3>Confirmar Contraseña:</h3>
										<input type="password" placeholder="Contraseña" name="pass2" class="form-control" id="contra2">
									</div>

									<div class="form-group">
										<input type="file" name="foto" required="" id="foto">
									</div>
									<div class="form-group">
										<input type="submit" placeholder="Nombre/s" name="enviar" class="btn btn-primary" id="Enviar">
									</div>
								</form>
							</div>

						</div>
					</div>
				</div>
			</div>
		</div>

		<script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.js"></script>
		<script src="../js/jquery.min.js"></script>
		<script src="../js/bootstrap.bundle.min.js"></script>
		<script type="text/javascript" src="../js/server-petition.js"></script>
		<script type="text/javascript">	
			$("#menu-toggle").click(function(e) {
				e.preventDefault();
				$("#wrapper").toggleClass("toggled");
			});	



		</script>
	</body>
	</html>
	<?php }else{
		?>
		<!DOCTYPE html>
		<html lang="es">
		<head>
			<meta charset="utf-8">
			<meta http-equiv="X-UA-Compatible" content="IE=edge">
			<meta name="viewport" content="width=device-width, initial-scale=1">

			<title>Página Principal</title>
			<link href="../css/bootstrap.css" rel="stylesheet">
			<link href="../css/sidebar.css" rel="stylesheet">
			<link rel="stylesheet" href="../css/galeria.css">
			<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Material+Icons">
			<link rel="shortcut icon" href="../icono/seguridad-icono1.png">
			<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.css">
		</head>
		<body>

			<?php require ("sidebar.php") ?>
			<div id="page-content-wrapper">
				<?php require ("top-bar.php") ?>
				<div class="container-fluid">
					<?php 

					?>
					<div class="container gallery-container">
						<h1>Agregar un usuario nuevo.</h1>
						<center></center>
						<div class="row">
							<div class="col-md-12 col-xs-12 centered well">
								<form id="formulario" method="post" class="formcontrol" action="enviar-agusuario.php" enctype="multipart/form-data">
									<div class="form-group"><h3>Nombre/s:</h3>
										<input type="text" placeholder="Nombre/s" name="nombre" class="form-control" id="nombre">
									</div>
									<div class="form-group"><h3>Apellido/s:</h3>
										<input type="text" placeholder="Apellido/s" name="apellido" class="form-control" id="apellido">
									</div>
									<div class="form-group"><h3>Usuario:</h3>
										<input type="text" placeholder="Nombre de usuario" name="usuario" class="form-control" id="usuario">
									</div>
									<div class="form-group"><h3>Correo:</h3>
										<input type="text" placeholder="Correo Electrónico" name="correo" class="form-control" id="email">
									</div>
									<div class="form-group"><h3>Contraseña:</h3>
										<input type="password" placeholder="Contraseña" name="pass" class="form-control" id="contra1">
									</div>
									<div class="form-group"><h3>Confirmar Contraseña:</h3>
										<input type="password" placeholder="Contraseña" name="pass2" class="form-control" id="contra2">
									</div>

									<div class="form-group">
										<input type="file" name="foto" required="" id="foto">
									</div>
									<div class="form-group">
										<input type="submit" placeholder="Nombre/s" name="enviar" class="btn btn-primary" id="Enviar">
									</div>
								</form>
							</div>

						</div>
					</div>
				</div>
			</div>
		</div>

		<script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.js"></script>
		<script src="../js/jquery.min.js"></script>
		<script src="../js/bootstrap.bundle.min.js"></script>
		<script type="text/javascript" src="../js/server-petition.js"></script>
		<script type="text/javascript">	
			$("#menu-toggle").click(function(e) {
				e.preventDefault();
				$("#wrapper").toggleClass("toggled");
			});	



		</script>
	</body>
	</html>
	<?php

}
} ?>