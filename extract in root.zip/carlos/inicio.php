<?php 
$_SESSION['user']=$_POST['Usuario'];
$_SESSION['contra']=$_POST['Contra'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname ="cocina";

// Create connection
$conn = mysqli_connect($servername, $username, $password,$dbname);

// Check connection
if (mysqli_connect_errno()) {
	echo "failed to connect to MySQL: ".mysqli_connect_error();
} 
//echo "Connected successfully";

$sql="SELECT * FROM usuarios where usuario='".$_SESSION["user"]."'";
$result=mysqli_query($conn,$sql);
if ($result) {
	$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
	$img=$row['imagen'];
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<img src=<?php echo "'$img'";?>>
</body>
</html>
