<html !DOCTYPE>
<head>
	<title>Bootstrap 3 Collapsible Sidebar</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="css/custom.css">
	<style type="text/css">
	.wrapper {
		display: flex;
		align-items: stretch;
	}

	#sidebar {
		min-width: 250px;
		max-width: 250px;
		min-height: 100vh;
	}

	#sidebar.active {
		margin-left: -250px;
	}
	a[data-toggle="collapse"] {
		position: relative;
	}

	a[aria-expanded="false"]::before, a[aria-expanded="true"]::before {
		content: '\e259';
		display: block;
		position: absolute;
		right: 20px;
		font-family: 'Glyphicons Halflings';
		font-size: 0.6em;
	}

	a[aria-expanded="true"]::before {
		content: '\e260';
	}
	@media (max-width: 768px) {
		#sidebar {
			margin-left: -250px;
		}
		#sidebar.active {
			margin-left: 0;
		}
	}

    @import "https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700";


    body {
    	font-family: 'Poppins', sans-serif;
    	background: #fafafa;
    }

    p {
    	font-family: 'Poppins', sans-serif;
    	font-size: 1.1em;
    	font-weight: 300;
    	line-height: 1.7em;
    	color: #999;
    }

    a, a:hover, a:focus {
    	color: inherit;
    	text-decoration: none;
    	transition: all 0.3s;
    }

    #sidebar {
    	background: #7386D5;
    	color: #fff;
    	transition: all 0.3s;
    }

    #sidebar .sidebar-header {
    	padding: 20px;
    	background: #6d7fcc;
    }

    #sidebar ul.components {
    	padding: 20px 0;
    	border-bottom: 1px solid #47748b;
    }

    #sidebar ul p {
    	color: #fff;
    	padding: 10px;
    }

    #sidebar ul li a {
    	padding: 10px;
    	font-size: 1.1em;
    	display: block;
    }
    #sidebar ul li a:hover {
    	color: #7386D5;
    	background: #fff;
    }

    #sidebar ul li.active > a, a[aria-expanded="true"] {
    	color: #fff;
    	background: #6d7fcc;
    }
    ul ul a {
    	font-size: 0.9em !important;
    	padding-left: 30px !important;
    	background: #6d7fcc;
    }
</style>
<script type="text/javascript">
	$(document).ready(function () {

		$('#sidebarCollapse').on('click', function () {
			$('#sidebar').toggleClass('active');
		});

	});
</script>
</head>
<body>
	<div class="wrapper">

		<nav id="sidebar">

			<div class="sidebar-header">
				<h3>MENU LATERAL</h3>
			</div>

			<ul class="list-unstyled components">
				<li class="active"><a href="#">INICIO</a></li>
				<li><a href="#">ACERCA</a></li>

				<li>
					<a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false">PAGINAS</a>
					<ul class="collapse list-unstyled" id="homeSubmenu">
						<li><a href="#">PAGINA 1</a></li>
						<li><a href="#">PAGINA 2</a></li>
						<li><a href="#">PAGINA 3</a></li>
					</ul>

					<li><a href="#">PORTAFOLIO</a></li>
					<li><a href="#">CONTACTO</a></li>
				</ul>
			</nav>

		</div>


		<script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

	</body>
	</html>